//
//  Food.swift
//  Meal Tracker
//
//  Created byStudent on 18/08/25.
//

import Foundation

struct Food {
    var emoji: String
    var name: String
    var description: String
}
