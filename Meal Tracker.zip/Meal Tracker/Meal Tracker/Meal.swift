//
//  Meal.swift
//  Meal Tracker
//
//  Created byStudent on 18/08/25.
//

import Foundation

struct Meal {
    var name: String
    var food: [Food]
}
